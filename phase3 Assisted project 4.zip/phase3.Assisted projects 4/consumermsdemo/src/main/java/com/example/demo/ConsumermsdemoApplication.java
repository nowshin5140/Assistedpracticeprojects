package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConsumermsdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConsumermsdemoApplication.class, args);
	}

}
