package com.example.demo;


import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class controllerVacCenter {
	@Autowired
	ServiceVacCenter dao;
	
	Logger log = Logger.getAnonymousLogger();

	@RequestMapping("/")
	public ModelAndView basePage(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("Login.jsp");
		return mv;
	}
	
	@RequestMapping("/AddUser")
	public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		
		User user = new User();
		user.setUserName(request.getParameter("userName"));
		user.setUserEmail(request.getParameter("userEmail"));
		user.setUserPassword(request.getParameter("userPassword"));
		
		User u = dao.addUser(user);
		if(u!=null) {
			mv.setViewName("registersuccess.jsp");
			return mv;
		}
		else {
			mv.setViewName("Fail.jsp");
			return mv;
		}
		
	}
	
	@RequestMapping("/Login")
	public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		
		String email =request.getParameter("userEmail");
		String password =request.getParameter("userPassword");
		
		User user = dao.userLogin(email, password);
		//log.info(user.toString());
		
		if(user!=null) {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			mv.setViewName("Home.jsp");
			mv.addObject("user", user);
			return mv;
		}
		else {
			mv.setViewName("Fail.jsp");
			return mv;
		}
		}
	
	@RequestMapping("/allCitizen")
	public ModelAndView allCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		
		List<Citizen> list = dao.getAllCitizen();
		mv.setViewName("Citizen.jsp");
		mv.addObject("list", list);
		return mv;	
	}
	
	@RequestMapping("/allVacCenter")
	public ModelAndView allCenters(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		
		List<VaccinationCenter> list = dao.getAllCenter();
		mv.setViewName("VacCenter.jsp");
		mv.addObject("list", list);
		return mv;	
	}
	
	@RequestMapping("/AddCitizen")
	public ModelAndView addCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Citizen c = new Citizen();
		c.setCitizenName(request.getParameter("citizenName"));
		c.setCitizenCity(request.getParameter("citizenCity"));
		c.setNoOfDoses(request.getParameter("noOfDose"));
		c.setVaccinationStatus(request.getParameter("vacStatus"));
		
		VaccinationCenter center = new VaccinationCenter();
		center.setCenterName(request.getParameter("centerName"));
		center.setCenterCity(request.getParameter("centerCity"));
		
		c.setCitizenVacCenter(center);
		
		Citizen citizen = dao.addCitizen(c);
		if(citizen!=null) {
			List<Citizen> list = dao.getAllCitizen();
			mv.setViewName("Citizen.jsp");
			mv.addObject("list", list);
			return mv;
		}
		else {
			mv.setViewName("Fail.jsp");
			return mv;
		}
		
		
	}
	
	@RequestMapping("/AddCenter")
	public ModelAndView addCenter(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		VaccinationCenter ce = new VaccinationCenter();
		ce.setCenterName(request.getParameter("centerName"));
		ce.setCenterCity(request.getParameter("centerCity"));
		
		VaccinationCenter center = dao.addCenter(ce);
		if(center!=null) {
			List<VaccinationCenter> list = dao.getAllCenter();
			mv.setViewName("VacCenter.jsp");
			mv.addObject("list", list);
			return mv;
		}
		else {
			mv.setViewName("Fail.jsp");
			return mv;
		}
	}
	
	@RequestMapping(value ="/DeleteCitizen{id}", method=RequestMethod.GET)
	public ModelAndView deleteCitizen(@RequestParam("id") int id, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		//int id = Integer.parseInt(request.getParameter("id"));

		log.info("Got into delete controller with value="+id);
		dao.deleteCitizen(id);
		
		List<Citizen> list = dao.getAllCitizen();
		mv.setViewName("Citizen.jsp");
		mv.addObject("list", list);
		
		return mv;
	}
	
	@RequestMapping(value ="/ViewCitizen{id}", method=RequestMethod.GET)
	public ModelAndView viewCitizen(@RequestParam("id") int id, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		Citizen c = dao.getCitizen(id);
		mv.setViewName("ViewCitizen.jsp");
		mv.addObject("citizen", c);
		return mv;
		
	}
	
	@RequestMapping(value ="/ViewCenter{id}", method=RequestMethod.GET)
	public ModelAndView viewCenter(@RequestParam("id") int id, HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		VaccinationCenter center = dao.getCenter(id);
		Citizen citizen = dao.citizenInCenter(id);
		mv.setViewName("ViewCenter.jsp");
		mv.addObject("center", center);
		mv.addObject("citizen", citizen);
		return mv;	
	}
	
	@RequestMapping("/Logout")
	public ModelAndView logOut(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		HttpSession session = request.getSession();
		session.invalidate();
		mv.setViewName("Login.jsp");
		return mv;
	}
	
	@RequestMapping(value ="/EditCitizen")
	public ModelAndView editCitizen(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		int id = Integer.parseInt(request.getParameter("id"));
		Citizen c = dao.getCitizen(id);
		
		c.setCitizenId(id);
		c.setCitizenName(request.getParameter("citizenName"));
		c.setCitizenCity(request.getParameter("citizenCity"));
		c.setNoOfDoses(request.getParameter("noOfDose"));
		c.setVaccinationStatus(request.getParameter("vacStatus"));
		
		VaccinationCenter center = dao.getCenter(id);
		center.setCenterId(id);
		center.setCenterName(request.getParameter("centerName"));
		center.setCenterCity(request.getParameter("centerCity"));
		
		c.setCitizenVacCenter(center);
		dao.addCitizen(c);
		List<Citizen> list = dao.getAllCitizen();
		mv.setViewName("Citizen.jsp");
		mv.addObject("list", list);
		return mv;
	}
	
	@RequestMapping(value ="/EditCenter")
	public ModelAndView editCenter(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mv = new ModelAndView();
		int id = Integer.parseInt(request.getParameter("id"));
		VaccinationCenter center = dao.getCenter(id);
		center.setCenterId(id);
		center.setCenterName(request.getParameter("centerName"));
		center.setCenterCity(request.getParameter("centerCity"));
		dao.addCenter(center);
		List<VaccinationCenter> list = dao.getAllCenter();
		mv.setViewName("VacCenter.jsp");
		mv.addObject("list", list);
		return mv;
	}
}
