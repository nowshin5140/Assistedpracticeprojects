package com.example.demo;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Citizen {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int citizenId;
	private String citizenName;
	private String citizenCity;
	private String noOfDoses;
	private String vaccinationStatus;
	@OneToOne(targetEntity = VaccinationCenter.class, cascade = CascadeType.ALL)
	@JoinTable(name="Citizen_VacCenter",
			joinColumns= {@JoinColumn(name="citizenId", referencedColumnName="citizenId")},
			inverseJoinColumns= {@JoinColumn(name="centerid", referencedColumnName="centerId")})
	private VaccinationCenter citizenVacCenter;
}
