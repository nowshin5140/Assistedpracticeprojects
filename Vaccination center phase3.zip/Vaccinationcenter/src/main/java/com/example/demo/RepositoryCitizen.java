package com.example.demo;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RepositoryCitizen extends JpaRepository<Citizen, Integer> {
	String query = "select c from Citizen c join c.citizenVacCenter vc where vc.centerId=?1";
	@Query(query)
	public Citizen citizenInCenter(int id);
	public Citizen getById(int id);
}


